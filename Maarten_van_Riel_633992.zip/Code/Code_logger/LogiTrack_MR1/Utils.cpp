/**
 * @file Utils.h
 * @brief Utility functions used across the datalogger project.
 *
 * This header contains helper functions that are shared between multiple modules.
 */

#include "Utils.h"


