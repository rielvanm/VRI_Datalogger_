var searchData=
[
  ['_5fcspin_0',['_csPin',['../class_s_d_manager.html#a83e5d271649cba8908e65e0ec1d98356',1,'SDManager']]]
];
