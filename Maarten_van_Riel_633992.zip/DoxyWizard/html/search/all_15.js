var searchData=
[
  ['year_0',['YEAR',['../class_display_manager.html#a8fa3173741a0954a26f63b3b8ed62fbead18101729d290479023d5eceeb29c9cf',1,'DisplayManager']]]
];
