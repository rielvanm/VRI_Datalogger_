var searchData=
[
  ['elapsmillis_0',['elapsMillis',['../class_r_t_c_manager.html#aa67fec00b330090ead5d3a8ebfccb916',1,'RTCManager']]]
];
