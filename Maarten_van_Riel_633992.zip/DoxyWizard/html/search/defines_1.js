var searchData=
[
  ['sd_5fcs_5fpin_0',['SD_CS_PIN',['../_display_manager_8cpp.html#a04d57a6c18b2d5e81f31093e58ed0c62',1,'DisplayManager.cpp']]],
  ['sensor_5fpin_1',['SENSOR_PIN',['../_display_manager_8cpp.html#a18f465739f27d321f5486101919a72f8',1,'DisplayManager.cpp']]]
];
