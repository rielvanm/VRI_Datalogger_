var searchData=
[
  ['logging_0',['Logging',['../class_display_manager.html#aeb1de54e39fc0be568de185df65fa3eaa8db7df66ab1d7ab5f1dc947acdb5fae4',1,'DisplayManager']]]
];
