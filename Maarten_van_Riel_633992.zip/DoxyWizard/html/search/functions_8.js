var searchData=
[
  ['issdavailable_0',['isSdAvailable',['../class_display_manager.html#a485a03d78bc22cd8bc1c983e0bd26e46',1,'DisplayManager']]],
  ['issdwritable_1',['isSdWritable',['../class_display_manager.html#a219952a9881a08b269af9602d329a12d',1,'DisplayManager']]]
];
