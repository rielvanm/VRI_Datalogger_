var searchData=
[
  ['now_0',['now',['../class_r_t_c_manager.html#a1e0f557bcd6981c092ead091e00a65bf',1,'RTCManager']]]
];
