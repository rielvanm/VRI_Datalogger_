var searchData=
[
  ['transferpending_0',['transferPending',['../class_trigger_buffer.html#ae2659471e6e639962aad26afd360e3f7',1,'TriggerBuffer']]]
];
