var searchData=
[
  ['currentfield_0',['currentField',['../class_display_manager.html#a0d8dbb20d52bb75e747a48edfd1135c1',1,'DisplayManager']]],
  ['currentstate_1',['currentState',['../class_display_manager.html#a92762b65129986444ea6224ee7909feb',1,'DisplayManager']]]
];
