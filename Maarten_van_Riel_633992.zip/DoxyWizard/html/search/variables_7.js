var searchData=
[
  ['lastbuttonstate_0',['lastButtonState',['../class_button_manager.html#a8ec5db287b98e816edb44022c5e127e9',1,'ButtonManager']]],
  ['lastdebouncetime_1',['lastDebounceTime',['../class_button_manager.html#aa0bc82c4062b1f2e5506b22c9af98eb8',1,'ButtonManager']]],
  ['lastinterruptcounter_2',['lastInterruptCounter',['../class_display_manager.html#a21b1bd87c677758f752fb4eeec04df8d',1,'DisplayManager']]],
  ['lastinterrupttimedisplay_3',['lastInterruptTimeDisplay',['../class_button_manager.html#aa758964836e84fc99237daf0a958972a',1,'ButtonManager']]],
  ['lastirtriggertime_4',['lastIrTriggerTime',['../class_display_manager.html#a45442c531412fdf0012e16ed529d04d6',1,'DisplayManager']]],
  ['lastsdchecktime_5',['lastSdCheckTime',['../class_display_manager.html#a8d9c528581ce416e81e091131d251a62',1,'DisplayManager']]],
  ['lastsdstatus_6',['lastSdStatus',['../class_display_manager.html#ab7e8f59e8c972259c77bf72b571a2f6c',1,'DisplayManager']]],
  ['lastsensorstatus_7',['lastSensorStatus',['../class_display_manager.html#a9050d8638b074d4a8d1a613c57771365',1,'DisplayManager']]],
  ['laststatuschecktime_8',['lastStatusCheckTime',['../class_display_manager.html#a563900d7a0462def82b2d13363c098f8',1,'DisplayManager']]]
];
