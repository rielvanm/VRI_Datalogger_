var searchData=
[
  ['writable_0',['writable',['../class_display_manager.html#a8108844305c0007132c86659344b8ae9',1,'DisplayManager']]]
];
